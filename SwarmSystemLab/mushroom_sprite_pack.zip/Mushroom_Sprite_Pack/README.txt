Mushroom Sprite Pack 🍄
-----------------------

By Peter Field

This pack includes 6 original 32x32 pixel art mushroom sprites in a "Mystic Forest" theme:
- Red Mushroom
- Orange Mushroom
- Maroon Mushroom
- Purple Mushroom
- Light Red Mushroom
- Dark Red Mushroom

🎨 Color Palette: Muted and magical forest tones, perfect for fantasy or whimsical environments.

🧙‍♂️ Format: PNG files, transparent background, 32x32 px

🔓 License:
These sprites are free to use in personal and commercial projects.
Credit is appreciated but not required.

Happy devving
– Peter Field
